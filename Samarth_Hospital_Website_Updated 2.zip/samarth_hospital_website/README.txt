SAMARTH HOSPITAL WEBSITE PROTOTYPE

Files:
- index.html — responsive website
- images/consultation-room-1.jpeg
- images/consultation-room-2.jpeg

Open index.html in a browser to preview it.

Before publishing, verify:
- hospital timings
- exact list of currently available facilities/services
- doctor qualifications and titles
- Google Maps location
- appointment process
- whether any 24-hour availability statement should be published
